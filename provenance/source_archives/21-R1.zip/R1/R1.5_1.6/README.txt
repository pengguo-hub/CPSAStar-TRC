Reviewer 1 Comments 5-6: Gaussian-field parameter sensitivity

Run:
    python test_r1_gaussian_sensitivity.py

Required third-party package:
    numpy

Experiment settings:
- Maps A/B/C
- Task loads: A={50,70}, B={250,280}, C={150,200}
- Seeds: 42,43,44,45,46
- OFAT sweeps:
  L       = {0,1,2,3}
  T       = {0,1,2,3}
  sigma_l = {0.5,1,2,4}
  sigma_t = {0.5,1,2,4}
- Baseline: L=1, T=1, sigma_l=2, sigma_t=2
- Map A: h(s)=Manhattan + look-ahead congestion
- Maps B/C: h(s)=Manhattan only
- All maps: Gaussian congestion field remains in g(s)
- AC uses a fixed evaluation field L=1,T=1,sigma_l=2,sigma_t=2

Outputs are written under:
    result_R1_gaussian_sensitivity/run_YYYYMMDD_HHMMSS/
