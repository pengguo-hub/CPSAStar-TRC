# Independent package validation protocol

The delivered source tree is freshly zipped; no prior archive is reused. The final artifact must pass the actual command `unzip -t <archive>` with return code 0.

A new empty directory is created with tempfile.mkdtemp; the ZIP is extracted there. From the extracted project root, execute:

```bash
python tools/verify_package.py
python verify_sources.py
python run.py --formal --dry-run --output portable_formal_plan
```

Confirm 1440 planned rows, 90 workloads, identical input hashes for each matched 16-cell block, and no formal result files. A small extracted smoke worker may be executed as an additional portability check. The prior full 16-cell smoke need not be repeated to validate a packaging-only operation.

An external test harness installs a Python audit hook through a temporary sitecustomize.py solely for validation. It records and rejects access to the old /workspace or /mnt/data project paths. Python and installed third-party libraries are normal runtime dependencies and remain allowed. The test hook is not part of the simulation and does not impose a runtime limit.

The prepack independent check and logs are retained in this folder when generated. The final archive check is recorded in the accompanying final validation report, so there is no circular assertion that a ZIP contains the hash of itself.
