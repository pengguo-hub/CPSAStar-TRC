# Smoke 验证报告：固定 OD + 3000项初始任务

**验证样本：seeds 7、8；每个条件 n=2；共72 trials、36对 Full/Control。正式 seeds39–43 未运行。** 所有72次均到达500步，通过任务账目及事件重放检查；无失败、无超时、无缺失、无按性能筛选。每个trial仅一个attempt。保留了全部条件和两个seed。

## 设计执行检查

- 三张原始障碍地图；AGV数为 STANDARD30/50、FRANSEN100/200、RING80/160。
- 每次3000项任务、全部release=0、375个均衡OD区块；没有lambda或增量到达。
- 全部126份正式/验证输入已预生成并校验，正式180个trial仅做dry-run，执行数为0。
- 原始规划源码及Full/Control机制保持字节一致；FRANSEN的OD节点和三个排列与R2-05配置完全一致。
- 对216000条任务记录、36000个时间区间和36072帧位置完成审计；初始位置、任务身份、等待/移动/完成时间、队列长度和守恒关系均通过。

## Full 相对 Control 的差异

下表为两seed均值之差相对Control均值的百分比；吞吐量正值有利，其他三项负值有利。它描述smoke效应大小，不代表正式显著性。完整绝对均值、配对差和95%区间位于 `smoke_summary/paired_statistics.csv`。

| 地图 | AGV | OD模式 | 吞吐量Δ% | 等待Δ% | 流程Δ% | 队列Δ% |
|---|---:|---|---:|---:|---:|---:|
| STANDARD | 30 | dispersed | +0.75 | -0.11 | -0.09 | -0.09 |
| STANDARD | 30 | intermediate | -0.93 | +0.06 | +0.07 | +0.08 |
| STANDARD | 30 | shared | -1.65 | +0.24 | +0.26 | +0.27 |
| STANDARD | 50 | dispersed | +3.90 | -0.48 | -0.40 | -0.41 |
| STANDARD | 50 | intermediate | +3.97 | -0.50 | -0.36 | -0.38 |
| STANDARD | 50 | shared | +0.56 | -0.33 | -0.20 | -0.22 |
| FRANSEN | 100 | dispersed | +7.39 | -2.47 | -2.08 | -2.21 |
| FRANSEN | 100 | intermediate | +13.38 | -3.89 | -3.26 | -3.47 |
| FRANSEN | 100 | shared | +14.64 | -3.37 | -2.77 | -2.96 |
| FRANSEN | 200 | dispersed | +17.21 | -3.20 | -2.50 | -2.79 |
| FRANSEN | 200 | intermediate | +20.73 | -5.16 | -4.18 | -4.64 |
| FRANSEN | 200 | shared | +16.74 | -3.39 | -2.72 | -3.01 |
| RING | 80 | dispersed | +0.11 | -0.02 | +0.07 | +0.07 |
| RING | 80 | intermediate | +1.58 | -0.44 | -0.32 | -0.33 |
| RING | 80 | shared | +2.22 | -0.11 | +0.02 | +0.01 |
| RING | 160 | dispersed | +14.98 | -2.72 | -1.99 | -2.20 |
| RING | 160 | intermediate | +6.20 | -1.21 | -0.76 | -0.86 |
| RING | 160 | shared | +6.18 | -1.00 | -0.59 | -0.67 |

## 数据 → 判断 → 原因

**STANDARD。数据：** 吞吐量相对差范围-1.65%至+3.97%；等待时间相对差范围-0.50%至+0.24%；流程时间相对差范围-0.40%至+0.26%；队列长度相对差范围-0.41%至+0.27%；6个条件均为n=2，其中4/6的四项均值方向同时有利于Full。

**判断：** 效应依赖车队和OD模式；不能由FRANSEN的结果推断本地图所有条件稳定改善。较小或不利的差异均保留在表中。

**原因：** 静态分数仅控制不同OD最短路的内部空间重叠，不控制车辆抵达时间、空驶取货段、实际绕路或动态分配。原始CPS-A*的软项在不同拓扑和车辆密度下作用不同，因此静态模式间距本身不能保证算法差异同样增大。

**FRANSEN。数据：** 吞吐量相对差范围+7.39%至+20.73%；等待时间相对差范围-5.16%至-2.47%；流程时间相对差范围-4.18%至-2.08%；队列长度相对差范围-4.64%至-2.21%；6个条件均为n=2，其中6/6的四项均值方向同时有利于Full。

**判断：** 在两个车队规模、三种OD模式下，验证均值均显示吞吐量增加，并伴随等待、流程时间和任务队列下降；这些效应支持开展冻结的正式实验。两个seed不足以确认正式效应或普遍规律。

**原因：** 初始3000项任务持续提供工作负载，软等待惩罚和局部拥堵优先级能够影响正在竞争路线与预约的车辆。OD模式之间又保持了端点频次和逐任务最短距离，使性能比较不会被更短的取放货距离解释。这里识别的是两个软项的联合作用，不是把静态拥堵分数下降当成原因——两arm的静态分数相同。

**RING。数据：** 吞吐量相对差范围+0.11%至+14.98%；等待时间相对差范围-2.72%至-0.02%；流程时间相对差范围-1.99%至+0.07%；队列长度相对差范围-2.20%至+0.07%；6个条件均为n=2，其中4/6的四项均值方向同时有利于Full。

**判断：** 效应依赖车队和OD模式；不能由FRANSEN的结果推断本地图所有条件稳定改善。较小或不利的差异均保留在表中。

**原因：** 静态分数仅控制不同OD最短路的内部空间重叠，不控制车辆抵达时间、空驶取货段、实际绕路或动态分配。原始CPS-A*的软项在不同拓扑和车辆密度下作用不同，因此静态模式间距本身不能保证算法差异同样增大。

## 拥堵模式的差异与算法差异分开报告

下表在每个arm内部比较 shared−dispersed（各n=2），保留相同seed配对。正吞吐量差表示shared反而更高；不可预先强制单调。

| 地图 | AGV | Arm | 吞吐量Δ% | 等待Δ% | 流程Δ% | 队列Δ% |
|---|---:|---|---:|---:|---:|---:|
| STANDARD | 30 | control | -3.20 | +0.31 | +0.33 | +0.33 |
| STANDARD | 30 | full | -5.50 | +0.66 | +0.69 | +0.69 |
| STANDARD | 50 | control | -4.87 | +0.69 | +0.76 | +0.76 |
| STANDARD | 50 | full | -7.93 | +0.85 | +0.96 | +0.95 |
| FRANSEN | 100 | control | -15.55 | +4.07 | +3.54 | +3.76 |
| FRANSEN | 100 | full | -9.85 | +3.11 | +2.81 | +2.96 |
| FRANSEN | 200 | control | -15.45 | +4.95 | +4.44 | +4.86 |
| FRANSEN | 200 | full | -15.79 | +4.76 | +4.21 | +4.62 |
| RING | 80 | control | -6.44 | +1.19 | +1.07 | +1.12 |
| RING | 80 | full | -4.47 | +1.10 | +1.02 | +1.06 |
| RING | 160 | control | +1.96 | -0.45 | -0.29 | -0.34 |
| RING | 160 | full | -5.85 | +1.32 | +1.13 | +1.22 |

## 等待与流程指标为何比吞吐量的百分比变化小

**数据：** 全部72次的平均任务活动比例范围为89.18%–99.24%；500步时未完成任务比例为52.30%–83.20%。 等待和流程均以固定3000项任务为分母，unfinished请求贡献截至500步的实际观察时间。

**判断：** 当前任务供给已充分占用车队；大量未完成任务仍使全队列平均时间接近观察上限，所以吞吐量提升不会转化为同等百分比的平均时间下降。

**原因：** 对每个请求有flow=queue-wait+assigned-stall+movement；总体flow=(mean task queue+mean assigned WIP)×500/3000。流程与队列因而紧密相关，不能将四项结果当作四份统计独立证据。全体请求统计避免了只统计已完成任务的选择偏差；不为放大差异改换指标分母。

## 全部主指标的绝对值和区间

区间为独立seed配对差的95% t区间。n=2时区间很宽，数值用于透明展示smoke不确定性。正式仍按预先固定的5个seed运行。

| 条件 | 指标 | Control均值 | Full均值 | Full−Control | 95% CI | n |
|---|---|---:|---:|---:|---|---:|
| STANDARD_N30_dispersed | throughput | 1.064 | 1.072 | +0.008 | [-0.272, +0.288] | 2 |
| STANDARD_N30_dispersed | waiting_time | 452.127 | 451.650 | -0.477 | [-15.830, +14.876] | 2 |
| STANDARD_N30_dispersed | flow_time | 456.426 | 456.031 | -0.395 | [-15.219, +14.429] | 2 |
| STANDARD_N30_dispersed | queue_length | 2709.002 | 2706.665 | -2.337 | [-92.081, +87.407] | 2 |
| STANDARD_N30_intermediate | throughput | 1.077 | 1.067 | -0.010 | [-0.137, +0.117] | 2 |
| STANDARD_N30_intermediate | waiting_time | 451.809 | 452.093 | +0.284 | [-8.015, +8.583] | 2 |
| STANDARD_N30_intermediate | flow_time | 456.212 | 456.548 | +0.337 | [-7.748, +8.422] | 2 |
| STANDARD_N30_intermediate | queue_length | 2707.590 | 2709.688 | +2.098 | [-46.923, +51.119] | 2 |
| STANDARD_N30_shared | throughput | 1.030 | 1.013 | -0.017 | [-0.157, +0.123] | 2 |
| STANDARD_N30_shared | waiting_time | 453.526 | 454.613 | +1.088 | [-3.122, +5.298] | 2 |
| STANDARD_N30_shared | flow_time | 457.954 | 459.167 | +1.213 | [-2.940, +5.365] | 2 |
| STANDARD_N30_shared | queue_length | 2718.043 | 2725.286 | +7.243 | [-17.725, +32.211] | 2 |
| STANDARD_N50_dispersed | throughput | 1.129 | 1.173 | +0.044 | [-0.388, +0.476] | 2 |
| STANDARD_N50_dispersed | waiting_time | 448.749 | 446.577 | -2.172 | [-7.816, +3.471] | 2 |
| STANDARD_N50_dispersed | flow_time | 453.731 | 451.934 | -1.797 | [-5.556, +1.962] | 2 |
| STANDARD_N50_dispersed | queue_length | 2675.460 | 2664.511 | -10.949 | [-35.688, +13.790] | 2 |
| STANDARD_N50_intermediate | throughput | 1.084 | 1.127 | +0.043 | [-0.580, +0.666] | 2 |
| STANDARD_N50_intermediate | waiting_time | 450.856 | 448.609 | -2.247 | [-26.761, +22.268] | 2 |
| STANDARD_N50_intermediate | flow_time | 455.663 | 454.031 | -1.632 | [-22.991, +19.727] | 2 |
| STANDARD_N50_intermediate | queue_length | 2687.229 | 2677.032 | -10.197 | [-141.922, +121.528] | 2 |
| STANDARD_N50_shared | throughput | 1.074 | 1.080 | +0.006 | [-0.045, +0.057] | 2 |
| STANDARD_N50_shared | waiting_time | 451.854 | 450.370 | -1.484 | [-4.961, +1.993] | 2 |
| STANDARD_N50_shared | flow_time | 457.181 | 456.273 | -0.908 | [-3.699, +1.883] | 2 |
| STANDARD_N50_shared | queue_length | 2695.743 | 2689.936 | -5.807 | [-23.431, +11.817] | 2 |
| FRANSEN_N100_dispersed | throughput | 2.572 | 2.762 | +0.190 | [-0.394, +0.774] | 2 |
| FRANSEN_N100_dispersed | waiting_time | 385.300 | 375.798 | -9.501 | [-56.103, +37.101] | 2 |
| FRANSEN_N100_dispersed | flow_time | 398.177 | 389.878 | -8.298 | [-53.689, +37.092] | 2 |
| FRANSEN_N100_dispersed | queue_length | 2292.697 | 2242.085 | -50.612 | [-324.634, +223.410] | 2 |
| FRANSEN_N100_intermediate | throughput | 2.436 | 2.762 | +0.326 | [+0.174, +0.478] | 2 |
| FRANSEN_N100_intermediate | waiting_time | 390.525 | 375.351 | -15.174 | [-30.521, +0.173] | 2 |
| FRANSEN_N100_intermediate | flow_time | 402.928 | 389.790 | -13.138 | [-29.311, +3.035] | 2 |
| FRANSEN_N100_intermediate | queue_length | 2321.700 | 2241.084 | -80.616 | [-176.827, +15.595] | 2 |
| FRANSEN_N100_shared | throughput | 2.172 | 2.490 | +0.318 | [-0.851, +1.487] | 2 |
| FRANSEN_N100_shared | waiting_time | 400.996 | 387.496 | -13.500 | [-75.936, +48.936] | 2 |
| FRANSEN_N100_shared | flow_time | 412.272 | 400.841 | -11.431 | [-65.606, +42.744] | 2 |
| FRANSEN_N100_shared | queue_length | 2378.847 | 2308.461 | -70.386 | [-404.280, +263.508] | 2 |
| FRANSEN_N200_dispersed | throughput | 2.388 | 2.799 | +0.411 | [-0.339, +1.161] | 2 |
| FRANSEN_N200_dispersed | waiting_time | 387.109 | 374.712 | -12.397 | [-53.942, +29.148] | 2 |
| FRANSEN_N200_dispersed | flow_time | 400.305 | 390.298 | -10.007 | [-51.040, +31.025] | 2 |
| FRANSEN_N200_dispersed | queue_length | 2221.700 | 2159.769 | -61.931 | [-308.419, +184.557] | 2 |
| FRANSEN_N200_intermediate | throughput | 2.132 | 2.574 | +0.442 | [-1.311, +2.195] | 2 |
| FRANSEN_N200_intermediate | waiting_time | 402.190 | 381.440 | -20.750 | [-110.450, +68.949] | 2 |
| FRANSEN_N200_intermediate | flow_time | 413.903 | 396.596 | -17.306 | [-94.912, +60.299] | 2 |
| FRANSEN_N200_intermediate | queue_length | 2304.778 | 2197.884 | -106.894 | [-585.511, +371.723] | 2 |
| FRANSEN_N200_shared | throughput | 2.019 | 2.357 | +0.338 | [-1.720, +2.396] | 2 |
| FRANSEN_N200_shared | waiting_time | 406.287 | 392.532 | -13.755 | [-130.659, +103.148] | 2 |
| FRANSEN_N200_shared | flow_time | 418.088 | 406.723 | -11.365 | [-121.130, +98.400] | 2 |
| FRANSEN_N200_shared | queue_length | 2329.736 | 2259.556 | -70.180 | [-736.976, +596.616] | 2 |
| RING_N80_dispersed | throughput | 1.833 | 1.835 | +0.002 | [-0.049, +0.053] | 2 |
| RING_N80_dispersed | waiting_time | 415.475 | 415.385 | -0.090 | [-9.541, +9.362] | 2 |
| RING_N80_dispersed | flow_time | 427.467 | 427.766 | +0.299 | [-7.377, +7.976] | 2 |
| RING_N80_dispersed | queue_length | 2485.627 | 2487.365 | +1.738 | [-46.495, +49.971] | 2 |
| RING_N80_intermediate | throughput | 1.772 | 1.800 | +0.028 | [-0.124, +0.180] | 2 |
| RING_N80_intermediate | waiting_time | 418.312 | 416.465 | -1.847 | [-7.572, +3.877] | 2 |
| RING_N80_intermediate | flow_time | 430.171 | 428.815 | -1.356 | [-5.414, +2.702] | 2 |
| RING_N80_intermediate | queue_length | 2502.030 | 2493.700 | -8.330 | [-34.556, +17.896] | 2 |
| RING_N80_shared | throughput | 1.715 | 1.753 | +0.038 | [-0.114, +0.190] | 2 |
| RING_N80_shared | waiting_time | 420.403 | 419.940 | -0.463 | [-9.252, +8.325] | 2 |
| RING_N80_shared | flow_time | 432.040 | 432.145 | +0.106 | [-9.079, +9.290] | 2 |
| RING_N80_shared | queue_length | 2513.462 | 2513.819 | +0.357 | [-54.216, +54.930] | 2 |
| RING_N160_dispersed | throughput | 1.635 | 1.880 | +0.245 | [-0.301, +0.791] | 2 |
| RING_N160_dispersed | waiting_time | 425.573 | 413.981 | -11.592 | [-78.740, +55.556] | 2 |
| RING_N160_dispersed | flow_time | 437.035 | 428.356 | -8.680 | [-65.682, +48.322] | 2 |
| RING_N160_dispersed | queue_length | 2476.978 | 2422.469 | -54.509 | [-407.475, +298.457] | 2 |
| RING_N160_intermediate | throughput | 1.678 | 1.782 | +0.104 | [-0.353, +0.561] | 2 |
| RING_N160_intermediate | waiting_time | 422.982 | 417.857 | -5.125 | [-14.380, +4.129] | 2 |
| RING_N160_intermediate | flow_time | 435.012 | 431.692 | -3.320 | [-7.456, +0.816] | 2 |
| RING_N160_intermediate | queue_length | 2464.250 | 2443.016 | -21.234 | [-51.831, +9.363] | 2 |
| RING_N160_shared | throughput | 1.667 | 1.770 | +0.103 | [-1.053, +1.259] | 2 |
| RING_N160_shared | waiting_time | 423.659 | 419.428 | -4.231 | [-96.459, +87.997] | 2 |
| RING_N160_shared | flow_time | 435.762 | 433.194 | -2.567 | [-80.759, +75.625] | 2 |
| RING_N160_shared | queue_length | 2468.655 | 2452.090 | -16.565 | [-500.405, +467.275] | 2 |

## 重放与正式运行

- `python replay_packaged_smoke.py --output replayed_smoke`：只重放包内72次原始证据，不运行仿真。
- `python test_integrity.py --output integrity_checks.json`：验证篡改任务等待、输入、指标或arm设置会被拒绝。
- `python run.py --formal --suite all --output results_od_formal`：正式180次；用户自行运行。
- `python postprocess.py results_od_formal`：审计、配对统计和两张综合图。

图中均明确标注SMOKE；本报告不替代正式Reviewer回复。
