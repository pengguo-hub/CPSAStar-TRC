# Result audit

Purpose: **smoke**.

Audited valid trials: 14/14. No missing or failed trial was imputed.

Statistics use independent seeds, never tasks or frames. No confidence interval is computed for n=1.

Completion fraction is completed/released; the paper success percentage completed/net-assigned is separate.

Planning time is cumulative original batch work with measured observer callback time subtracted. Pure-time and total-wall scopes are separate columns.

These checks establish task/record consistency, not physical collision correctness.

Traffic labels denote fixed OD pairings, not proven low/medium/high realized congestion. Read traffic metrics and paired intervals before making a congestion-gradient claim.

**VALIDATION ONLY. Do not use these results or figures as formal manuscript evidence.**
